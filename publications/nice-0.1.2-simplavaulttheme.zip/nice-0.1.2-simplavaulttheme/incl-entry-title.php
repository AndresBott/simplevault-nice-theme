<div class="element">
<label>Category:</label> <span class="bold"><?php echo escape_for_html($cat) ?></span>
</div>
<div class="element">
<label>Title:</label> <span class="bold"><?php echo escape_for_html($t1) ?></span>
</div>
<div class="element">
<label>Subtitle:</label> <span class="bold"><?php echo escape_for_html($t2) ?></span>
</div>


