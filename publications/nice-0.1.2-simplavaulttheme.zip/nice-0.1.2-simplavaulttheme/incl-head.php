<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" id="style-css" href="tpl-std/css/style_0.2.min.css" type="text/css" media="all">
<script id="jquery"  src="tpl-std/js/jquery.min.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="robots" content="noarchive,nofollow" />
<meta http-equiv="cache-control" content="no-cache" />
<title><?php echo $pgtitle ?> - Simple Vault</title>
<link rel="shortcut icon" href="tpl-std/img/favicon.png" />
