<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<head>
<?php include "$template/incl-head.php"; ?>
</head>

<body>
	<div id="wrap">
		<?php include "$template/incl-titlebar.php"; ?>
		
		<div class="tool">
			<h2> <i class=" icon-unlock "></i> <?php echo ucfirst($decrmode) ?> Entry</h2>
			
				<?php include "$template/incl-entry-title.php"; ?>
		</div>
		<div class="tool encrypted">
			<h4> <i class=" icon-lock"></i> Encrypted:</h4>	
				<?php include "$template/incl-entry-body.php"; ?>
		</div>
		<div class="footer"><span>Password manager powered by <a href="http://simplevault.sourceforge.net">SimpleVault</a></span></div>
	</div>
<footer>
<?php include "$template/incl-footer.php"; ?>