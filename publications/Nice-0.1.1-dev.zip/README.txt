Simple Vault theme
========
nice theme for Theme for simple vault.


INSTALL
=========
backup folder tpl-std and rename this folder to this name

ABOUT
=========
Author: Andres Bott www.andresbott.com
License: GPL3
version:0.1.1 - 2013-01-29
background based on http://subtlepatterns.com/black-leather/  http://subtlepatterns.com

